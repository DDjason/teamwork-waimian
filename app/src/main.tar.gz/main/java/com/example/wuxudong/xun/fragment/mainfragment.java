package com.example.wuxudong.xun.fragment;

import android.app.Fragment;

/**
 * Created by wuxudong on 17-3-30.
 */

public class mainfragment extends Fragment {
    /*@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        View view = inflater.inflate(R.layout., container,false);
        return view;
    }*/
}
